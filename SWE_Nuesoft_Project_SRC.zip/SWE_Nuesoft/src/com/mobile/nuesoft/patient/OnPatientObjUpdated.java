package com.mobile.nuesoft.patient;

import android.os.Bundle;

public interface OnPatientObjUpdated {

	public void onPatientObjUpdated(final Bundle b);
}
